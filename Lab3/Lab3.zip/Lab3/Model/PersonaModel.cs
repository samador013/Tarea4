﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace Lab3.Model
{
    public class PersonaModel
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Descripcion { get; set; }

        public PersonaModel() { }

        public static ObservableCollection<PersonaModel> ObtenerPersonas()
        {
            //aqui se llamaria a un API x ej, q me devuelve un json para llenar la lista
            ObservableCollection<PersonaModel> lst = new ObservableCollection<PersonaModel>();
            lst.Add(new PersonaModel { Id= 1, Nombre="Sharon"});
            lst.Add(new PersonaModel { Id = 2, Nombre = "Maria" });
            lst.Add(new PersonaModel { Id = 3, Nombre = "Jorge" });
            lst.Add(new PersonaModel { Id = 4, Nombre = "Sam" });
            lst.Add(new PersonaModel { Id = 5, Nombre = "Stephanie" });

            return lst;
        }
    }
}
